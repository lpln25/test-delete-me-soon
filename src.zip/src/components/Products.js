import React from 'react';
import './Products.css'

class Products extends React.Component{
    render(){
        const productItem = this.props.products.map(product =>
            <div className="col-md-4 text-center product" key={product.id}>
                <div>
                    {/* <img src={`products/0${product.id}.jpg`} ></img> */}
                    <img src={`products/${product.address}`}  alt={product.title}></img>
                </div>
                <div>
                    <p>{product.title}</p>
                    <p className="price">{product.price}</p>
                    <button
                    onClick={(e) => this.props.handleAddToCart(e,product)}
                    className="btn btn-primary">افزودن به سبد خرید</button>
                </div>
            </div>
            )
        return(
            <div className="row">
                {productItem}
            </div>
        )
    }
}

export default Products;